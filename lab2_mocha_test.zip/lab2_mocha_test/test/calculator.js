
function sum (a,b){
 let a =3;
 let b =2;   
 let result= a+b;
 return result;

}
function div (a,b){
    let a =3;
    let b =2;   
    let result= a/b;
    return result;
   
   }
   function mul (a,b){
    let a =3;
    let b =2;   
    let result= a*b;
    return result;
   
   }
   function sum (a,b){
    let a =3;
    let b =2;   
    let result= a+b;
    return result;
   
   }